﻿namespace Food_Management_System
{
    partial class UserRequests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvRequests = new System.Windows.Forms.DataGridView();
            this.approvebtn = new System.Windows.Forms.Button();
            this.nametb = new Guna.UI2.WinForms.Guna2TextBox();
            this.emailtb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.usernametb = new Guna.UI2.WinForms.Guna2TextBox();
            this.rolecb = new Guna.UI2.WinForms.Guna2ComboBox();
            this.deletebtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvRequests
            // 
            this.dgvRequests.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequests.Location = new System.Drawing.Point(698, 238);
            this.dgvRequests.Name = "dgvRequests";
            this.dgvRequests.Size = new System.Drawing.Size(422, 211);
            this.dgvRequests.TabIndex = 0;
            this.dgvRequests.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRequests_CellContentClick);
            this.dgvRequests.SelectionChanged += new System.EventHandler(this.dgvRequests_SelectionChanged);
            // 
            // approvebtn
            // 
            this.approvebtn.BackColor = System.Drawing.Color.Green;
            this.approvebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.approvebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.approvebtn.ForeColor = System.Drawing.Color.White;
            this.approvebtn.Location = new System.Drawing.Point(815, 458);
            this.approvebtn.Name = "approvebtn";
            this.approvebtn.Size = new System.Drawing.Size(90, 37);
            this.approvebtn.TabIndex = 248;
            this.approvebtn.Text = "Approve";
            this.approvebtn.UseVisualStyleBackColor = false;
            this.approvebtn.Click += new System.EventHandler(this.approvebtn_Click);
            // 
            // nametb
            // 
            this.nametb.BorderColor = System.Drawing.Color.Green;
            this.nametb.BorderRadius = 18;
            this.nametb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nametb.DefaultText = "";
            this.nametb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.nametb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.nametb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.nametb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.nametb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.nametb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.nametb.ForeColor = System.Drawing.Color.Green;
            this.nametb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.nametb.Location = new System.Drawing.Point(472, 238);
            this.nametb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nametb.Name = "nametb";
            this.nametb.PlaceholderText = "";
            this.nametb.SelectedText = "";
            this.nametb.Size = new System.Drawing.Size(164, 34);
            this.nametb.TabIndex = 253;
            // 
            // emailtb
            // 
            this.emailtb.BorderColor = System.Drawing.Color.Green;
            this.emailtb.BorderRadius = 18;
            this.emailtb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailtb.DefaultText = "";
            this.emailtb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.emailtb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.emailtb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailtb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailtb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailtb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.emailtb.ForeColor = System.Drawing.Color.Green;
            this.emailtb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailtb.Location = new System.Drawing.Point(472, 298);
            this.emailtb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.emailtb.Name = "emailtb";
            this.emailtb.PlaceholderText = "";
            this.emailtb.SelectedText = "";
            this.emailtb.Size = new System.Drawing.Size(164, 33);
            this.emailtb.TabIndex = 254;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(334, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 255;
            this.label5.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(300, 306);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 19);
            this.label1.TabIndex = 256;
            this.label1.Text = "Email address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(343, 362);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 19);
            this.label2.TabIndex = 258;
            this.label2.Text = "Role";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(275, 430);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 19);
            this.label3.TabIndex = 260;
            this.label3.Text = "Generate Username";
            // 
            // usernametb
            // 
            this.usernametb.BorderColor = System.Drawing.Color.Green;
            this.usernametb.BorderRadius = 18;
            this.usernametb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.usernametb.DefaultText = "";
            this.usernametb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.usernametb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.usernametb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.usernametb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.usernametb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.usernametb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.usernametb.ForeColor = System.Drawing.Color.Green;
            this.usernametb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.usernametb.Location = new System.Drawing.Point(472, 426);
            this.usernametb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usernametb.Name = "usernametb";
            this.usernametb.PlaceholderText = "";
            this.usernametb.SelectedText = "";
            this.usernametb.Size = new System.Drawing.Size(164, 33);
            this.usernametb.TabIndex = 259;
            // 
            // rolecb
            // 
            this.rolecb.BackColor = System.Drawing.Color.Transparent;
            this.rolecb.BorderColor = System.Drawing.Color.Green;
            this.rolecb.BorderRadius = 18;
            this.rolecb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.rolecb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rolecb.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.rolecb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.rolecb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.rolecb.ForeColor = System.Drawing.Color.Green;
            this.rolecb.ItemHeight = 30;
            this.rolecb.Items.AddRange(new object[] {
            "Admin",
            "Cashier",
            "Product Manager"});
            this.rolecb.Location = new System.Drawing.Point(472, 352);
            this.rolecb.Name = "rolecb";
            this.rolecb.Size = new System.Drawing.Size(164, 36);
            this.rolecb.TabIndex = 261;
            // 
            // deletebtn
            // 
            this.deletebtn.BackColor = System.Drawing.Color.Green;
            this.deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deletebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.deletebtn.ForeColor = System.Drawing.Color.White;
            this.deletebtn.Location = new System.Drawing.Point(939, 458);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(90, 37);
            this.deletebtn.TabIndex = 262;
            this.deletebtn.Text = "Delete";
            this.deletebtn.UseVisualStyleBackColor = false;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(568, 144);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(319, 37);
            this.label4.TabIndex = 280;
            this.label4.Text = "VIEW USER REQUESTS";
            // 
            // UserRequests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 768);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.rolecb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.usernametb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.nametb);
            this.Controls.Add(this.emailtb);
            this.Controls.Add(this.approvebtn);
            this.Controls.Add(this.dgvRequests);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UserRequests";
            this.Text = "UserRequests";
            this.Load += new System.EventHandler(this.UserRequests_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvRequests;
        private System.Windows.Forms.Button approvebtn;
        private Guna.UI2.WinForms.Guna2TextBox nametb;
        private Guna.UI2.WinForms.Guna2TextBox emailtb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox usernametb;
        private Guna.UI2.WinForms.Guna2ComboBox rolecb;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Label label4;
    }
}