﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_Management_System
{
    public partial class UserRequests : Form
    {
        public UserRequests()
        {
            InitializeComponent();
        }
        //function for loading data in datagridview
        private void LoadUserRequests()
        {
            string query = "SELECT RequestID, Name, Email, Role, Status FROM UserRequests WHERE Status = 'Pending'";
            DataTable dt = db_connection.GetData(query);

            if (dt != null)
            {
                dgvRequests.DataSource = dt;
                dgvRequests.Columns["RequestID"].Visible = false;
            }
        }

        private void UserRequests_Load(object sender, EventArgs e)
        {
            LoadUserRequests();
        }
        //approve button action
        private void approvebtn_Click(object sender, EventArgs e)
        {
            if (dgvRequests.SelectedRows.Count > 0)
            {
                int requestID = Convert.ToInt32(dgvRequests.SelectedRows[0].Cells["RequestID"].Value);
                string fullName = nametb.Text.Trim();
                string email = emailtb.Text.Trim();
                string role = rolecb.SelectedItem?.ToString();
                string username = usernametb.Text.Trim();
                string password = GenerateRandomPassword();
                string hashedPassword = HashPassword(password);

                if (string.IsNullOrEmpty(username))
                {
                    MessageBox.Show("Please enter a username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string insertUserQuery = "INSERT INTO Users (Name, Email, Username, Password, Role) VALUES (@FullName, @Email, @Username, @PasswordHash, @Role)";
                SqlParameter[] userParams = {
                    new SqlParameter("@FullName", fullName),
                    new SqlParameter("@Email", email),
                    new SqlParameter("@Username", username),
                    new SqlParameter("@PasswordHash", hashedPassword),
                    new SqlParameter("@Role", role)
                };

                bool userAdded = db_connection.ExecuteQuery(insertUserQuery, userParams);

                if (userAdded)
                {
                    string updateRequestQuery = "UPDATE UserRequests SET Status='Approved' WHERE RequestID=@RequestID";
                    SqlParameter[] requestParams = { new SqlParameter("@RequestID", requestID) };
                    db_connection.ExecuteQuery(updateRequestQuery, requestParams);

                    SendEmail(email, username, password);

                    MessageBox.Show("User Approved & Credentials Sent!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadUserRequests();
                }
                else
                {
                    MessageBox.Show("Failed to approve user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        
        

        private void dgvRequests_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        //Function to generate password
        private string GenerateRandomPassword()
        {
            Random rand = new Random();
            int num = rand.Next(1000000, 9999999);
            return num.ToString();
        }
        //Function to Send Email
        private void SendEmail(string email, string username, string password)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("hafizhannan7067@gmail.com");
                mail.To.Add(email);
                mail.Subject = "Your Account Credentials";
                mail.Body = $"Hello,\n\nYour account at the FoodFusion has been approved!\n\nUsername: {username}\nPassword: {password}\n\nPlease change your password after logging in.\n\nBest Regards,\nThe FoodFusion";

                smtp.Port = 587;
                smtp.Credentials = new NetworkCredential("hafizhannan7067@gmail.com", "yjzo bfxg haia klon");
                smtp.EnableSsl = true;

                smtp.Send(mail);
                MessageBox.Show("Email sent successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to send email: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Function for Hashing Password
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }
        //Delete Button action
        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dgvRequests.SelectedRows.Count > 0)
            {
                int requestID = Convert.ToInt32(dgvRequests.SelectedRows[0].Cells["RequestID"].Value);
                string deleteQuery = "DELETE FROM UserRequests WHERE RequestID = @RequestID";

                SqlParameter[] parameters = { new SqlParameter("@RequestID", requestID) };

                bool deleted = db_connection.ExecuteQuery(deleteQuery, parameters);

                if (deleted)
                {
                    MessageBox.Show("User request deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadUserRequests(); // Refresh DataGridView
                }
                else
                {
                    MessageBox.Show("Failed to delete request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvRequests_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvRequests.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvRequests.SelectedRows[0];

                nametb.Text = row.Cells["Name"].Value.ToString();
                emailtb.Text = row.Cells["Email"].Value.ToString();
                rolecb.SelectedItem = row.Cells["Role"].Value.ToString();
                usernametb.Text = ""; // Admin manually fills this
            }
            
        }
    }
}
