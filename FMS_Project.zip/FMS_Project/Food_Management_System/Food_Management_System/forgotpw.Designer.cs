﻿namespace Food_Management_System
{
    partial class forgotpw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.emailtb = new Guna.UI2.WinForms.Guna2TextBox();
            this.otptb = new Guna.UI2.WinForms.Guna2TextBox();
            this.sendotpbtn = new System.Windows.Forms.Button();
            this.verifyotp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(32, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 19);
            this.label5.TabIndex = 258;
            this.label5.Text = "Email Address";
            // 
            // emailtb
            // 
            this.emailtb.BorderColor = System.Drawing.Color.Green;
            this.emailtb.BorderRadius = 18;
            this.emailtb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailtb.DefaultText = "";
            this.emailtb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.emailtb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.emailtb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailtb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailtb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailtb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.emailtb.ForeColor = System.Drawing.Color.Green;
            this.emailtb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailtb.Location = new System.Drawing.Point(198, 77);
            this.emailtb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.emailtb.Name = "emailtb";
            this.emailtb.PlaceholderText = "";
            this.emailtb.SelectedText = "";
            this.emailtb.Size = new System.Drawing.Size(164, 34);
            this.emailtb.TabIndex = 256;
            // 
            // otptb
            // 
            this.otptb.BorderColor = System.Drawing.Color.Green;
            this.otptb.BorderRadius = 18;
            this.otptb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.otptb.DefaultText = "";
            this.otptb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.otptb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.otptb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.otptb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.otptb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.otptb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.otptb.ForeColor = System.Drawing.Color.Green;
            this.otptb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.otptb.Location = new System.Drawing.Point(198, 137);
            this.otptb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.otptb.Name = "otptb";
            this.otptb.PlaceholderText = "";
            this.otptb.SelectedText = "";
            this.otptb.Size = new System.Drawing.Size(164, 33);
            this.otptb.TabIndex = 257;
            // 
            // sendotpbtn
            // 
            this.sendotpbtn.BackColor = System.Drawing.Color.Green;
            this.sendotpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sendotpbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.sendotpbtn.ForeColor = System.Drawing.Color.White;
            this.sendotpbtn.Location = new System.Drawing.Point(398, 77);
            this.sendotpbtn.Name = "sendotpbtn";
            this.sendotpbtn.Size = new System.Drawing.Size(110, 37);
            this.sendotpbtn.TabIndex = 263;
            this.sendotpbtn.Text = "Send OTP";
            this.sendotpbtn.UseVisualStyleBackColor = false;
            this.sendotpbtn.Click += new System.EventHandler(this.sendotpbtn_Click_1);
            // 
            // verifyotp
            // 
            this.verifyotp.BackColor = System.Drawing.Color.Green;
            this.verifyotp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.verifyotp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.verifyotp.ForeColor = System.Drawing.Color.White;
            this.verifyotp.Location = new System.Drawing.Point(398, 136);
            this.verifyotp.Name = "verifyotp";
            this.verifyotp.Size = new System.Drawing.Size(110, 37);
            this.verifyotp.TabIndex = 264;
            this.verifyotp.Text = " Verify OTP";
            this.verifyotp.UseVisualStyleBackColor = false;
            this.verifyotp.Click += new System.EventHandler(this.verifyotp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(32, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 19);
            this.label1.TabIndex = 265;
            this.label1.Text = "Enter OTP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(148, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(263, 37);
            this.label2.TabIndex = 274;
            this.label2.Text = "OTP VERIFICATION";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::Food_Management_System.Properties.Resources.oottpp;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(79, 6);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(64, 61);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 273;
            this.guna2PictureBox1.TabStop = false;
            // 
            // forgotpw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(524, 195);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.verifyotp);
            this.Controls.Add(this.sendotpbtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.emailtb);
            this.Controls.Add(this.otptb);
            this.Name = "forgotpw";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.forgotpw_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox emailtb;
        private Guna.UI2.WinForms.Guna2TextBox otptb;
        private System.Windows.Forms.Button sendotpbtn;
        private System.Windows.Forms.Button verifyotp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}