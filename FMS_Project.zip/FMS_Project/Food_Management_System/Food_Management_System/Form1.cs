﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Food_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Welcome hah = new Welcome();
            hah.Show();
        }
        //Login Button CLick Event
        private void button4_Click(object sender, EventArgs e)
        {
            string username = emailtb.Text.Trim();
            string password = pwtb.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string hashedPassword = HashPassword(password); 

            string query = "SELECT Role FROM Users WHERE Username = @Username AND Password = @Password";
            SqlParameter[] parameters = {
        new SqlParameter("@Username", username),
        new SqlParameter("@Password", hashedPassword)
    };

            DataTable dt = db_connection.GetData(query, parameters);

            if (dt.Rows.Count > 0)
            {
                string role = dt.Rows[0]["Role"].ToString();

                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide(); 

                if (role == "Admin")
                {
                    AdminPanel adminForm = new AdminPanel();
                    adminForm.Show();
                }
                else
                {
                    //UserPanel userForm = new UserPanel();
                    //userForm.Show();
                }
            }
            else
            {
                MessageBox.Show("Invalid Username or Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pwtb.UseSystemPasswordChar = true;

        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            forgotpw forgotPasswordForm = new forgotpw();
            forgotPasswordForm.Show();
        }

        private void cross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void checkbox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkbox1.Checked==true)
            {
                pwtb.UseSystemPasswordChar=false;
            }
            else
            {
                pwtb.UseSystemPasswordChar=true;
            }
        }
    }
}
