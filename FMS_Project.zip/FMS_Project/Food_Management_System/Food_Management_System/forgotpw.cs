﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace Food_Management_System
{
    public partial class forgotpw : Form
    {
        private string generatedOTP;
        private string userEmail;
        public forgotpw()
        {
            InitializeComponent();
        }

        private void sendotpbtn_Click(object sender, EventArgs e)
        {
           

        }

        private void sendotpbtn_Click_1(object sender, EventArgs e)
        {
            userEmail = emailtb.Text.Trim();

            if (string.IsNullOrEmpty(userEmail))
            {
                MessageBox.Show("Please enter your email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "SELECT COUNT(*) FROM Users WHERE Email = @Email";
            SqlParameter[] parameters = { new SqlParameter("@Email", userEmail) };

            int count = Convert.ToInt32(db_connection.ExecuteScalar(query, parameters));

            if (count == 0)
            {
                MessageBox.Show("Email not found in our records.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Random random = new Random();
            generatedOTP = random.Next(100000, 999999).ToString();

            bool emailSent = SendEmailOTP(userEmail, generatedOTP);

            if (emailSent)
            {
                MessageBox.Show("OTP sent to your email.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to send OTP. Try again later.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void verifyotp_Click(object sender, EventArgs e)
        {
            string enteredOTP = otptb.Text.Trim();

            if (enteredOTP == generatedOTP)
            {
                MessageBox.Show("OTP Verified! Please enter your new password.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                PasswordReset resetForm = new PasswordReset(userEmail);
                this.Hide();
                resetForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid OTP. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool SendEmailOTP(string email, string otp)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("hafizhannan7067@gmail.com");
                mail.To.Add(email);
                mail.Subject = "Password Reset OTP";
                mail.Body = $"Your OTP for password reset is: {otp}";

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.Credentials = new NetworkCredential("hafizhannan7067@gmail.com", "yjzo bfxg haia klon");
                smtp.EnableSsl = true;

                smtp.Send(mail);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        private void forgotpw_Load(object sender, EventArgs e)
        {

        }
    }
}
