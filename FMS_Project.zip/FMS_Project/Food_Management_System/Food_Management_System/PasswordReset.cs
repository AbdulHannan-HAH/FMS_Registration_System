﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;


namespace Food_Management_System
{
    public partial class PasswordReset : Form
    {
        private string userEmail;
        public PasswordReset(string email)
        {
            InitializeComponent();
            userEmail = email;
        }

        private void resetpw_Click(object sender, EventArgs e)
        {
            string newPassword = pwttb.Text.Trim();
            string confirmPassword = pwtb.Text.Trim();

            if (string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Please enter both new password and confirm password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match! Please re-enter.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string hashedPassword = HashPassword(newPassword);

            string updateQuery = "UPDATE Users SET Password = @Password WHERE Email = @Email";
            SqlParameter[] parameters = {
                new SqlParameter("@Password", hashedPassword),
                new SqlParameter("@Email", userEmail)
            };

            int rowsAffected = db_connection.ExecuteNonQuery(updateQuery, parameters);

            if (rowsAffected > 0)
            {
                MessageBox.Show("Password updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                Form1 loginForm = new Form1();
                loginForm.Show();
            }
            else
            {
                MessageBox.Show("Failed to update password. Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private void checkbox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void PasswordReset_Load(object sender, EventArgs e)
        {
            pwttb.UseSystemPasswordChar = true;

        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2CheckBox1.Checked==true)
            {
                pwttb.UseSystemPasswordChar=false;
            }
            else
            {
                pwttb.UseSystemPasswordChar=true;
            }
        }
    }
}
