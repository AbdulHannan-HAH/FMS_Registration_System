﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_Management_System
{
    public partial class AdminPanel : Form
    {
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void usersRequestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserRequests hah = new UserRequests();
            LoadFormIntoPanel(hah);
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Successfully Logged Out!");
            this.Hide();
            Form1 hah = new Form1();
            hah.Show();
        }
        private void LoadFormIntoPanel(Form form)
        {
            pnlContainer.Controls.Clear();  
            form.TopLevel = false;  
            form.FormBorderStyle = FormBorderStyle.None;  
            form.Dock = DockStyle.Fill; 
            pnlContainer.Controls.Add(form);
            form.Show();
        }
        private void AdminPanel_Load(object sender, EventArgs e)
        {
            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.ImageScalingSize = new Size(24, 24);
            dashboardToolStripMenuItem.Image = Properties.Resources.dashboard;
            logoutToolStripMenuItem.Image=Properties.Resources.logout;
            usersRequestsToolStripMenuItem.Image=Properties.Resources.users;
            menuStrip1.ForeColor= Color.MidnightBlue;
           
        }

        private void pnlContainer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
           DashboardAdmin hah = new DashboardAdmin();
            LoadFormIntoPanel(hah);
        }
    }
}
