﻿namespace Food_Management_System
{
    partial class PasswordReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pwttb = new Guna.UI2.WinForms.Guna2TextBox();
            this.pwtb = new Guna.UI2.WinForms.Guna2TextBox();
            this.resetpw = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2CheckBox1 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(31, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 19);
            this.label1.TabIndex = 269;
            this.label1.Text = "Confirm Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(35, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 19);
            this.label5.TabIndex = 268;
            this.label5.Text = "Enter Password";
            // 
            // pwttb
            // 
            this.pwttb.BorderColor = System.Drawing.Color.Green;
            this.pwttb.BorderRadius = 18;
            this.pwttb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pwttb.DefaultText = "";
            this.pwttb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.pwttb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.pwttb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.pwttb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.pwttb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.pwttb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.pwttb.ForeColor = System.Drawing.Color.Green;
            this.pwttb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.pwttb.Location = new System.Drawing.Point(201, 82);
            this.pwttb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwttb.Name = "pwttb";
            this.pwttb.PlaceholderText = "";
            this.pwttb.SelectedText = "";
            this.pwttb.Size = new System.Drawing.Size(164, 34);
            this.pwttb.TabIndex = 266;
            // 
            // pwtb
            // 
            this.pwtb.BorderColor = System.Drawing.Color.Green;
            this.pwtb.BorderRadius = 18;
            this.pwtb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pwtb.DefaultText = "";
            this.pwtb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.pwtb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.pwtb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.pwtb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.pwtb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.pwtb.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.pwtb.ForeColor = System.Drawing.Color.Green;
            this.pwtb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.pwtb.Location = new System.Drawing.Point(201, 142);
            this.pwtb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtb.Name = "pwtb";
            this.pwtb.PlaceholderText = "";
            this.pwtb.SelectedText = "";
            this.pwtb.Size = new System.Drawing.Size(164, 33);
            this.pwtb.TabIndex = 267;
            // 
            // resetpw
            // 
            this.resetpw.BackColor = System.Drawing.Color.Green;
            this.resetpw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.resetpw.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.resetpw.ForeColor = System.Drawing.Color.White;
            this.resetpw.Location = new System.Drawing.Point(118, 197);
            this.resetpw.Name = "resetpw";
            this.resetpw.Size = new System.Drawing.Size(160, 37);
            this.resetpw.TabIndex = 270;
            this.resetpw.Text = "Reset Password";
            this.resetpw.UseVisualStyleBackColor = false;
            this.resetpw.Click += new System.EventHandler(this.resetpw_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(96, 25);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(269, 37);
            this.label2.TabIndex = 272;
            this.label2.Text = "RESET PASSWORD";
            // 
            // guna2CheckBox1
            // 
            this.guna2CheckBox1.AutoSize = true;
            this.guna2CheckBox1.CheckedState.BorderColor = System.Drawing.Color.Green;
            this.guna2CheckBox1.CheckedState.BorderRadius = 0;
            this.guna2CheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CheckBox1.CheckedState.FillColor = System.Drawing.Color.White;
            this.guna2CheckBox1.CheckMarkColor = System.Drawing.Color.Green;
            this.guna2CheckBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.guna2CheckBox1.ForeColor = System.Drawing.Color.White;
            this.guna2CheckBox1.Location = new System.Drawing.Point(335, 152);
            this.guna2CheckBox1.Name = "guna2CheckBox1";
            this.guna2CheckBox1.Size = new System.Drawing.Size(15, 14);
            this.guna2CheckBox1.TabIndex = 274;
            this.guna2CheckBox1.UncheckedState.BorderColor = System.Drawing.Color.Green;
            this.guna2CheckBox1.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox1.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox1.UncheckedState.FillColor = System.Drawing.Color.Green;
            this.guna2CheckBox1.CheckedChanged += new System.EventHandler(this.guna2CheckBox1_CheckedChanged);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::Food_Management_System.Properties.Resources.ppp_removebg_preview;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(27, 10);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(64, 61);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 271;
            this.guna2PictureBox1.TabStop = false;
            // 
            // PasswordReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 246);
            this.Controls.Add(this.guna2CheckBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.resetpw);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pwttb);
            this.Controls.Add(this.pwtb);
            this.Name = "PasswordReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Reset Password";
            this.Load += new System.EventHandler(this.PasswordReset_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox pwttb;
        private Guna.UI2.WinForms.Guna2TextBox pwtb;
        private System.Windows.Forms.Button resetpw;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox1;
    }
}