﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_Management_System
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            string name = nametb.Text;
            string email = emailtb.Text;
            string role = rolecb.SelectedItem.ToString();

            string query = "INSERT INTO UserRequests (Name, Email, Role) VALUES (@Name, @Email, @Role)";
            SqlParameter[] parameters = {
        new SqlParameter("@Name", name),
        new SqlParameter("@Email", email),
        new SqlParameter("@Role", role)
    };
            bool success = db_connection.ExecuteQuery(query, parameters);

            if (success)
            {

                MessageBox.Show("Your request is sent to admin. We will give you your credentials soon.", "Request Sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
                nametb.Text="";
                emailtb.Text="";
                rolecb.SelectedIndex=-1;
            }
            else
            {
                MessageBox.Show("Failed to send request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }










        private void memberComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void guna2GroupBox1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void guna2GroupBox1_Click(object sender, EventArgs e)
        {

        }

        private void cross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Welcome_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Label lbl = sender as Label;
            if (lbl != null)
            {
                lbl.Font = new Font(lbl.Font, lbl.Font.Style ^ FontStyle.Underline);
            }
            this.Hide();
            Form1 f=new Form1();
            f.Show();
        }
    }
}
